JUWAI MORNING TEER — ANDROID SOURCE PROJECT

This is an Android Studio source project (NOT a prebuilt APK).

Included UI:
- Navy blue + green native app design
- Five full-name Teer selectors
- FR/SR result card with manual refresh
- Six feature shortcuts and bottom navigation

Data connection:
- Juwai Morning Teer reads index.json (lowercase fr/sr keys).
- Shillong, Juwai, Khanapara and Shillong Night read games.shillong/juwai/khanapara/night from teer-feed-cache.json.
- JSON copies are included under app/src/main/assets as offline fallback.
- For live updates, upload index.json and teer-feed-cache.json to the website root: https://juwaimorningresult.com/
- The app requests those two URLs over HTTPS.

Other common-number JSON files are included in app/src/main/assets for the next feature integration step.
Feature shortcut URLs are inherited from the starter project and must be confirmed on the website before use.

Build: Open the JuwaiMorningTeerApp folder in Android Studio, sync Gradle, then Build > Build APK(s).
The project uses Java/Kotlin JVM 17. The APK has not been compiled or device-tested in this environment.
