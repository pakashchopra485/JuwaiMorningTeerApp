package com.juwai.morningteer

import android.annotation.SuppressLint
import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val navy = Color.rgb(2, 17, 32)
    private val panel = Color.rgb(4, 39, 65)
    private val green = Color.rgb(0, 235, 55)
    private val blue = Color.rgb(55, 145, 205)
    private val white = Color.WHITE
    private val base = "https://juwaimorningresult.com/"
    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private lateinit var marketStrip: LinearLayout
    private lateinit var frNumber: TextView
    private lateinit var srNumber: TextView
    private lateinit var dateLabel: TextView
    private lateinit var statusLabel: TextView
    private lateinit var web: WebView
    private var showingWeb = false
    private var selectedMarket = 0
    private var morningJson = JSONObject()
    private var feedJson = JSONObject()

    private val markets = listOf("Juwai Morning Teer", "Shillong Teer", "Juwai Teer", "Khanapara Teer", "Shillong Night Teer")
    private data class Feature(val title: String, val icon: String, val path: String)
    private val features = listOf(
        Feature("Common Number", "◎", "Common%20Number.php"),
        Feature("Deal Number", "ϟ", "deal.php"),
        Feature("Previous Results", "▤", "Previous%20Results.php"),
        Feature("Dream Number", "★", "dream.php"),
        Feature("Hit Number Chart", "▥", "analytics.php"),
        Feature("Teer Calendar", "▦", "calendar.php")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = navy
        window.navigationBarColor = navy
        buildApp()
        loadFallbackData()
        showHome()
        refreshLiveData()
    }

    private fun buildApp() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(navy) }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(dp(12), dp(12), dp(12), dp(10))
            background = gradient(navy, Color.rgb(1, 32, 55), 0, null)
        }
        header.addView(TextView(this).apply {
            text = "🎯  Teer Live Result"; textSize = 27f; gravity = Gravity.CENTER
            setTextColor(white); typeface = Typeface.create("sans-serif", Typeface.BOLD)
        })
        header.addView(TextView(this).apply {
            text = "DAILY TEER RESULT"; textSize = 13f; letterSpacing = .12f
            gravity = Gravity.CENTER; setTextColor(Color.rgb(170, 212, 238))
        })
        root.addView(header)

        val marketScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; setPadding(dp(5), dp(8), dp(5), dp(8)) }
        marketStrip = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        marketScroll.addView(marketStrip)
        root.addView(marketScroll)

        val scroll = ScrollView(this).apply { isFillViewport = true }
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(4), dp(12), dp(14)) }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
            background = gradient(Color.rgb(3, 30, 53), Color.rgb(4, 43, 70), dp(22), blue)
            setPadding(dp(4), dp(5), dp(4), dp(5))
        }
        listOf("⌂\nHome", "▤\nResults", "◎\nCommon", "▦\nCalendar", "☰\nMenu").forEachIndexed { i, label ->
            bottom.addView(TextView(this).apply {
                text = label; textSize = 12f; gravity = Gravity.CENTER; setTextColor(white); setPadding(dp(2), dp(8), dp(2), dp(8))
                if (i == 0) background = gradient(Color.rgb(0, 190, 25), Color.rgb(0, 95, 20), dp(18), green)
                setOnClickListener { when(i) {
                    0 -> showHome()
                    1 -> openFeature(features[2])
                    2 -> openFeature(features[0])
                    3 -> openFeature(features[5])
                    else -> showMenu()
                } }
            }, LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(bottom)
        setContentView(root)
        web = WebView(this).apply {
            settings.javaScriptEnabled = true; settings.domStorageEnabled = true
            webChromeClient = WebChromeClient(); webViewClient = WebViewClient()
        }
        refreshMarketButtons()
    }

    private fun showHome() {
        showingWeb = false
        content.removeAllViews()
        refreshMarketButtons()
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(14), dp(14), dp(16))
            background = gradient(Color.rgb(0, 55, 43), Color.rgb(2, 25, 43), dp(24), green)
        }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        row.addView(pill("● LIVE RESULT", Color.rgb(210, 24, 20)), LinearLayout.LayoutParams(0, -2, 1f))
        dateLabel = pill("--", Color.rgb(15, 75, 115)) as TextView
        row.addView(dateLabel)
        card.addView(row)
        card.addView(TextView(this).apply {
            text = markets[selectedMarket]; textSize = 24f; gravity = Gravity.CENTER; setTextColor(white)
            typeface = Typeface.create("sans-serif", Typeface.BOLD); setPadding(0, dp(14), 0, dp(12))
        })
        val nums = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        val frBox = numberBox("FR"); frNumber = frBox.tag as TextView
        val srBox = numberBox("SR"); srNumber = srBox.tag as TextView
        nums.addView(frBox, LinearLayout.LayoutParams(0, dp(126), 1f).apply { marginEnd = dp(8) })
        nums.addView(srBox, LinearLayout.LayoutParams(0, dp(126), 1f).apply { marginStart = dp(8) })
        card.addView(nums)
        statusLabel = TextView(this).apply {
            text = "Result data loading..."; textSize = 11f; gravity = Gravity.CENTER
            setTextColor(Color.rgb(177, 211, 226)); setPadding(0, dp(10), 0, 0)
        }
        card.addView(statusLabel)
        val refresh = TextView(this).apply {
            text = "↻  Refresh Result"; textSize = 14f; gravity = Gravity.CENTER; setTextColor(white)
            typeface = Typeface.DEFAULT_BOLD; setPadding(dp(12), dp(10), dp(12), dp(10))
            background = gradient(Color.rgb(0, 160, 45), Color.rgb(0, 95, 38), dp(18), green)
            setOnClickListener { refreshLiveData(); Toast.makeText(this@MainActivity, "Refreshing results...", Toast.LENGTH_SHORT).show() }
        }
        card.addView(refresh)
        content.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })

        val rows = listOf(features.take(3), features.drop(3))
        rows.forEach { group ->
            val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            group.forEach { f -> line.addView(featureTile(f), LinearLayout.LayoutParams(0, dp(112), 1f).apply { setMargins(dp(5), dp(5), dp(5), dp(5)) }) }
            content.addView(line)
        }
        updateDisplayedNumbers()
    }

    private fun refreshMarketButtons() {
        if (!::marketStrip.isInitialized) return
        marketStrip.removeAllViews()
        markets.forEachIndexed { index, name ->
            marketStrip.addView(TextView(this).apply {
                text = name; textSize = 12f; gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD
                setTextColor(white); setPadding(dp(10), dp(10), dp(10), dp(10))
                background = if(index == selectedMarket) gradient(Color.rgb(0,180,18), Color.rgb(0,92,17), dp(17), green)
                    else gradient(Color.rgb(4,45,72), Color.rgb(2,24,43), dp(17), green)
                setOnClickListener { selectedMarket = index; if (!showingWeb) showHome() }
            }, LinearLayout.LayoutParams(dp(137), dp(76)).apply { setMargins(dp(4), 0, dp(4), 0) })
        }
    }

    private fun featureTile(f: Feature): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
        background = gradient(Color.rgb(5,48,77), Color.rgb(2,27,48), dp(19), blue)
        setPadding(dp(5), dp(7), dp(5), dp(7)); setOnClickListener { openFeature(f) }
        addView(TextView(this@MainActivity).apply { text = f.icon; textSize = 30f; gravity = Gravity.CENTER; setTextColor(green); typeface = Typeface.DEFAULT_BOLD })
        addView(TextView(this@MainActivity).apply { text = f.title; textSize = 13f; gravity = Gravity.CENTER; setTextColor(white); typeface = Typeface.DEFAULT_BOLD })
    }

    private fun numberBox(label: String): LinearLayout {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; background = gradient(Color.WHITE, Color.rgb(220,239,250), dp(22), green) }
        box.addView(TextView(this).apply { text = label; textSize = 17f; setTextColor(Color.rgb(0,120,35)); typeface = Typeface.DEFAULT_BOLD })
        val value = TextView(this).apply { text = "--"; textSize = 48f; setTextColor(navy); typeface = Typeface.create("sans-serif", Typeface.BOLD) }
        box.addView(value)
        box.tag = value
        return box
    }

    private fun pill(t: String, c: Int): View = TextView(this).apply {
        text = t; textSize = 12f; gravity = Gravity.CENTER; setTextColor(white); typeface = Typeface.DEFAULT_BOLD
        setPadding(dp(10), dp(8), dp(10), dp(8)); background = gradient(c, c, dp(20), blue)
    }

    private fun loadFallbackData() {
        try { morningJson = JSONObject(assets.open("index.json").bufferedReader().use { it.readText() }) } catch (_: Exception) {}
        try { feedJson = JSONObject(assets.open("teer-feed-cache.json").bufferedReader().use { it.readText() }) } catch (_: Exception) {}
    }

    private fun refreshLiveData() {
        Thread {
            try {
                val morning = getJson("index.json")
                val feed = getJson("teer-feed-cache.json")
                runOnUiThread {
                    if (morning != null) morningJson = morning
                    if (feed != null) feedJson = feed
                    updateDisplayedNumbers()
                }
            } catch (_: Exception) { runOnUiThread { updateDisplayedNumbers() } }
        }.start()
    }

    private fun getJson(file: String): JSONObject? {
        val conn = (URL(base + file).openConnection() as HttpURLConnection)
        return try {
            conn.connectTimeout = 7000; conn.readTimeout = 7000; conn.requestMethod = "GET"
            if (conn.responseCode in 200..299) JSONObject(conn.inputStream.bufferedReader().use { it.readText() }) else null
        } finally { conn.disconnect() }
    }

    private fun updateDisplayedNumbers() {
        if (!::frNumber.isInitialized) return
        val (fr, sr, date) = when(selectedMarket) {
            0 -> Triple(morningJson.optString("fr", "--"), morningJson.optString("sr", "--"), morningJson.optString("date", ""))
            else -> {
                val key = when(selectedMarket) { 1 -> "shillong"; 2 -> "juwai"; 3 -> "khanapara"; else -> "night" }
                val game = feedJson.optJSONObject("games")?.optJSONObject(key)
                Triple(game?.optString("fr", "")?.ifBlank { "--" } ?: "--", game?.optString("sr", "")?.ifBlank { "--" } ?: "--", feedJson.optString("date", ""))
            }
        }
        frNumber.text = fr.ifBlank { "--" }
        srNumber.text = sr.ifBlank { "--" }
        dateLabel.text = date.ifBlank { SimpleDateFormat("dd MMM yyyy", Locale.ENGLISH).format(Date()) }
        statusLabel.text = if (frNumber.text == "--" && srNumber.text == "--") "Result not published yet" else "Latest result • Auto-updates from your website"
    }

    private fun openFeature(f: Feature) {
        showingWeb = true; content.removeAllViews()
        content.addView(TextView(this).apply {
            text = "‹   ${f.title}"; textSize = 19f; setTextColor(white); setPadding(dp(8), dp(12), dp(8), dp(12))
            setOnClickListener { showHome() }
        })
        web.loadUrl(base + f.path)
        (web.parent as? android.view.ViewGroup)?.removeView(web)
        content.addView(web, LinearLayout.LayoutParams(-1, dp(620)))
    }

    private fun showMenu() {
        val labels = arrayOf("Home", "Common Number", "Deal Number", "Previous Results", "Dream Number", "Hit Number Chart", "Teer Calendar")
        android.app.AlertDialog.Builder(this).setTitle("Teer Live Result").setItems(labels) { _, which ->
            if (which == 0) showHome() else openFeature(features[which - 1])
        }.setNegativeButton("Close", null).show()
    }

    private fun gradient(a: Int, b: Int, radius: Int, stroke: Int?): GradientDrawable = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(a,b)).apply {
        cornerRadius = radius.toFloat(); if(stroke != null) setStroke(dp(2), stroke)
    }
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (showingWeb) showHome() else super.onBackPressed() }
}
