JUWAI MORNING TEER ANDROID APP — FINAL UI SOURCE

This project contains the updated native Android app screen based on the approved design:
- Five full-name Teer selectors (no duplicate Shillong Teer)
- Juwai Morning Teer selected by default
- Navy/blue background with green highlights
- FR and SR result panels
- Common Number, Deal Number, Previous Results, Dream Number, Hit Number Chart and Teer Calendar shortcuts
- No auto-schedule or schedule time shown
- No separate Preview Result / Result List shortcut
- Bottom navigation

IMPORTANT:
1. This ZIP is Android Studio source code, not an APK.
2. The FR/SR values currently show "--" intentionally. The approved visual mockup used sample numbers; real result data has not yet been connected to the site's JSON/PHP structure.
3. Feature shortcut paths were retained from the starter project. Confirm those pages exist on the website before relying on each shortcut.
4. The project targets Java/Kotlin JVM 17 to avoid the previous Java 8 vs Kotlin 17 build mismatch.
5. Build APK in Android Studio: open this project folder, allow Gradle sync, then Build > Build Bundle(s) / APK(s) > Build APK(s).

Website: https://juwaimorningresult.com/
