package com.juwai.morningteer

import android.annotation.SuppressLint
import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val navy = Color.rgb(3, 20, 38)
    private val panel = Color.rgb(5, 39, 66)
    private val green = Color.rgb(0, 235, 55)
    private val blue = Color.rgb(53, 137, 190)
    private val white = Color.WHITE
    private val base = "https://juwaimorningresult.com/"
    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private lateinit var resultTitle: TextView
    private lateinit var frValue: TextView
    private lateinit var srValue: TextView
    private lateinit var marketStrip: LinearLayout
    private lateinit var web: WebView
    private var showingWeb = false
    private var selectedMarket = 0

    private val markets = listOf(
        "Juwai Morning Teer",
        "Shillong Teer",
        "Juwai Teer",
        "Khanapara Teer",
        "Shillong Night Teer"
    )

    private data class Feature(val title: String, val icon: String, val path: String)
    private val features = listOf(
        Feature("Common\nNumber", "◎", "Common%20Number.php"),
        Feature("Deal\nNumber", "ϟ", "deal.php"),
        Feature("Previous\nResults", "▤", "Previous%20Results.php"),
        Feature("Dream\nNumber", "★", "dream.php"),
        Feature("Hit Number\nChart", "▥", "analytics.php"),
        Feature("Teer\nCalendar", "▦", "calendar.php")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = navy
        window.navigationBarColor = navy
        window.decorView.systemUiVisibility = 0
        buildApp()
        showHome()
    }

    private fun buildApp() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(navy)
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(15), dp(14), dp(12))
            background = gradient(navy, Color.rgb(1, 31, 52), 0, null)
        }
        val brand = TextView(this).apply {
            text = "◎  Teer Live Result"
            textSize = 27f
            gravity = Gravity.CENTER
            setTextColor(white)
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
        }
        val subtitle = TextView(this).apply {
            text = "DAILY TEER RESULT"
            textSize = 13f
            letterSpacing = 0.12f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(170, 212, 238))
        }
        header.addView(brand)
        header.addView(subtitle)
        root.addView(header, LinearLayout.LayoutParams(-1, -2))

        val marketScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            setPadding(dp(5), dp(9), dp(5), dp(10))
        }
        marketStrip = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        marketScroll.addView(marketStrip)
        root.addView(marketScroll, LinearLayout.LayoutParams(-1, -2))

        val scroller = ScrollView(this).apply { isFillViewport = true }
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(4), dp(12), dp(14))
        }
        scroller.addView(content)
        root.addView(scroller, LinearLayout.LayoutParams(-1, 0, 1f))

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            background = gradient(Color.rgb(3, 30, 53), Color.rgb(4, 43, 70), dp(22), blue)
            setPadding(dp(4), dp(7), dp(4), dp(7))
        }
        listOf("⌂\nHome", "▤\nResults", "◎\nCommon", "▦\nCalendar", "☰\nMenu").forEachIndexed { i, label ->
            val item = TextView(this).apply {
                text = label
                textSize = 12f
                gravity = Gravity.CENTER
                setTextColor(white)
                setPadding(dp(3), dp(8), dp(3), dp(8))
                if (i == 0) background = gradient(Color.rgb(0, 190, 25), Color.rgb(0, 95, 20), dp(18), green)
                setOnClickListener {
                    when (i) {
                        0 -> showHome()
                        1 -> openFeature(Feature("Previous Results", "▤", "Previous%20Results.php"))
                        2 -> openFeature(Feature("Common Number", "◎", "Common%20Number.php"))
                        3 -> openFeature(Feature("Teer Calendar", "▦", "calendar.php"))
                        4 -> showMenu()
                    }
                }
            }
            bottom.addView(item, LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(bottom, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            webChromeClient = WebChromeClient()
            webViewClient = WebViewClient()
        }
        refreshMarketButtons()
    }

    private fun showHome() {
        showingWeb = false
        content.removeAllViews()
        refreshMarketButtons()

        val resultCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(16))
            background = gradient(Color.rgb(0, 55, 43), Color.rgb(2, 25, 43), dp(24), green)
        }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        top.addView(pill("● LIVE RESULT", Color.rgb(210, 24, 20)), LinearLayout.LayoutParams(0, -2, 1f))
        val date = SimpleDateFormat("dd MMM yyyy", Locale.ENGLISH).format(Date())
        top.addView(pill(date, Color.rgb(15, 75, 115)))
        resultCard.addView(top)
        resultTitle = TextView(this).apply {
            text = markets[selectedMarket]
            textSize = 24f
            gravity = Gravity.CENTER
            setTextColor(white)
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            setPadding(0, dp(14), 0, dp(12))
        }
        resultCard.addView(resultTitle)
        val numbers = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        numbers.addView(numberBox("FR", "--"), LinearLayout.LayoutParams(0, dp(125), 1f).apply { marginEnd = dp(8) })
        numbers.addView(numberBox("SR", "--"), LinearLayout.LayoutParams(0, dp(125), 1f).apply { marginStart = dp(8) })
        resultCard.addView(numbers)
        val note = TextView(this).apply {
            text = "Result data will appear here from the website"
            textSize = 11f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(177, 211, 226))
            setPadding(0, dp(10), 0, 0)
        }
        resultCard.addView(note)
        content.addView(resultCard, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(16) })

        val firstRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val secondRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        features.forEachIndexed { index, feature ->
            val tile = featureTile(feature)
            val target = if (index < 3) firstRow else secondRow
            target.addView(tile, LinearLayout.LayoutParams(0, dp(112), 1f).apply {
                val margin = dp(5)
                setMargins(margin, margin, margin, margin)
            })
        }
        content.addView(firstRow)
        content.addView(secondRow)
    }

    private fun refreshMarketButtons() {
        if (!::marketStrip.isInitialized) return
        marketStrip.removeAllViews()
        markets.forEachIndexed { index, name ->
            val btn = TextView(this).apply {
                text = name
                textSize = 12f
                gravity = Gravity.CENTER
                typeface = Typeface.create("sans-serif", Typeface.BOLD)
                setTextColor(white)
                setPadding(dp(12), dp(12), dp(12), dp(12))
                background = if (index == selectedMarket)
                    gradient(Color.rgb(0, 180, 18), Color.rgb(0, 92, 17), dp(17), green)
                else gradient(Color.rgb(4, 45, 72), Color.rgb(2, 24, 43), dp(17), green)
                setOnClickListener {
                    selectedMarket = index
                    if (!showingWeb) showHome()
                }
            }
            marketStrip.addView(btn, LinearLayout.LayoutParams(dp(132), dp(76)).apply {
                setMargins(dp(4), 0, dp(4), 0)
            })
        }
    }

    private fun featureTile(feature: Feature): View {
        val tile = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = gradient(Color.rgb(5, 48, 77), Color.rgb(2, 27, 48), dp(19), blue)
            setPadding(dp(5), dp(7), dp(5), dp(7))
            setOnClickListener { openFeature(feature) }
        }
        val icon = TextView(this).apply {
            text = feature.icon
            textSize = 30f
            gravity = Gravity.CENTER
            setTextColor(green)
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
        }
        val label = TextView(this).apply {
            text = feature.title
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(white)
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
        }
        tile.addView(icon)
        tile.addView(label)
        return tile
    }

    private fun numberBox(label: String, value: String): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = gradient(Color.WHITE, Color.rgb(220, 239, 250), dp(22), green)
        }
        box.addView(TextView(this).apply {
            text = label
            textSize = 17f
            setTextColor(Color.rgb(0, 120, 35))
            typeface = Typeface.DEFAULT_BOLD
        })
        box.addView(TextView(this).apply {
            text = value
            textSize = 48f
            setTextColor(navy)
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
        })
        return box
    }

    private fun pill(textValue: String, color: Int): View = TextView(this).apply {
        text = textValue
        textSize = 12f
        gravity = Gravity.CENTER
        setTextColor(white)
        typeface = Typeface.DEFAULT_BOLD
        setPadding(dp(10), dp(8), dp(10), dp(8))
        background = gradient(color, color, dp(20), blue)
    }

    private fun openFeature(feature: Feature) {
        showingWeb = true
        content.removeAllViews()
        val title = TextView(this).apply {
            text = "‹   ${feature.title.replace("\n", " ")}"
            textSize = 19f
            setTextColor(white)
            setPadding(dp(8), dp(12), dp(8), dp(12))
            setOnClickListener { showHome() }
        }
        content.addView(title)
        web.loadUrl(base + feature.path)
        (web.parent as? android.view.ViewGroup)?.removeView(web)
        content.addView(web, LinearLayout.LayoutParams(-1, dp(620)))
    }

    private fun showMenu() {
        val labels = arrayOf("Home", "Common Number", "Deal Number", "Previous Results", "Dream Number", "Hit Number Chart", "Teer Calendar")
        val paths = arrayOf("", "Common%20Number.php", "deal.php", "Previous%20Results.php", "dream.php", "analytics.php", "calendar.php")
        android.app.AlertDialog.Builder(this)
            .setTitle("Teer Live Result")
            .setItems(labels) { _, which ->
                if (which == 0) showHome()
                else openFeature(Feature(labels[which], "•", paths[which]))
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun gradient(start: Int, end: Int, radius: Int, stroke: Int?): GradientDrawable {
        return GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(start, end)).apply {
            cornerRadius = radius.toFloat()
            if (stroke != null) setStroke(dp(2), stroke)
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (showingWeb) showHome() else super.onBackPressed()
    }
}
