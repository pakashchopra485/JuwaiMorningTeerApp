package com.juwai.morningteer

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var pageTitle: TextView
    private val base = "https://juwaimorningresult.com/"
    private val navy = Color.rgb(18, 48, 78)
    private val green = Color.rgb(27, 145, 96)
    private val pale = Color.rgb(239, 246, 250)

    private data class Page(val label: String, val title: String, val path: String)
    // Main home categories, kept in the exact order requested.
    private val homeSections = listOf(
        Page("JUWAI MORNING TEER", "JUWAI MORNING TEER", "index.html"),
        Page("JUWAI TEER", "JUWAI TEER", "juwai-preview.php"),
        Page("SHILLONG TEER", "SHILLONG TEER", "shillong-preview.php"),
        Page("KHANAPARA TEER", "KHANAPARA TEER", "khanapara-preview.php"),
        Page("SHILLONG NIGHT", "SHILLONG NIGHT", "shillong-night-preview.php")
    )
    private val morePages = listOf(
        Page("Shillong Preview", "SHILLONG PREVIEW", "shillong-preview.php"),
        Page("Khanapara Preview", "KHANAPARA PREVIEW", "khanapara-preview.php"),
        Page("Shillong Night Preview", "SHILLONG NIGHT PREVIEW", "shillong-night-preview.php"),
        Page("Shillong Common", "SHILLONG COMMON NUMBER", "shillong-common-number.php"),
        Page("Khanapara Common", "KHANAPARA COMMON NUMBER", "khanapara-common-number.php"),
        Page("Shillong Night Common", "SHILLONG NIGHT COMMON NUMBER", "shillong-night-common-number.php"),
        Page("Dream Number", "DREAM NUMBER", "dream.php"),
        Page("Analytics", "RESULT ANALYTICS", "analytics.php"),
        Page("Updates", "LATEST UPDATES", "deal.php"),
        Page("Privacy Policy", "PRIVACY POLICY", "privacypolicy.php"),
        Page("Terms of Use", "TERMS OF USE", "termsofuse.php")
    )

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = navy
        window.navigationBarColor = navy
        window.decorView.systemUiVisibility = 0

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(17), dp(11), dp(17), dp(10))
            setBackgroundColor(navy)
        }
        val brand = TextView(this).apply {
            text = "◉  JUWAI MORNING TEER"
            textSize = 18f
            setTextColor(Color.WHITE)
            typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD)
        }
        pageTitle = TextView(this).apply {
            text = "LIVE RESULTS & UPDATES"
            textSize = 10f
            setTextColor(Color.rgb(195, 219, 235))
            setPadding(0, dp(3), 0, 0)
            letterSpacing = 0.08f
        }
        header.addView(brand)
        header.addView(pageTitle)
        root.addView(header, LinearLayout.LayoutParams(-1, -2))

        web = WebView(this).apply {
            setBackgroundColor(pale)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.databaseEnabled = true
            settings.loadsImagesAutomatically = true
            settings.javaScriptCanOpenWindowsAutomatically = true
            settings.setSupportMultipleWindows(false)
            settings.allowFileAccess = false
            settings.userAgentString = settings.userAgentString + " JuwaiMorningTeerApp/1.1"
            webChromeClient = WebChromeClient()
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    val uri = request?.url ?: return false
                    val host = uri.host ?: return false
                    if (host == "juwaimorningresult.com" || host == "www.juwaimorningresult.com") return false
                    return try {
                        startActivity(Intent(Intent.ACTION_VIEW, uri))
                        true
                    } catch (_: Exception) { true }
                }
            }
        }
        val sectionList = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setBackgroundColor(pale)
        }
        homeSections.forEachIndexed { index, page ->
            addHomeSection(sectionList, page, index == 0)
        }
        root.addView(sectionList, LinearLayout.LayoutParams(-1, -2))
        root.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))

        setContentView(root)
        openPage(homeSections[0])
    }

    private fun addHomeSection(parent: LinearLayout, page: Page, featured: Boolean) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(13), dp(16), dp(13))
            setBackgroundColor(if (featured) navy else Color.WHITE)
            elevation = dp(2).toFloat()
            setOnClickListener { openPage(page) }
        }
        val title = TextView(this).apply {
            text = page.label
            textSize = if (featured) 15f else 14f
            letterSpacing = 0.035f
            typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD)
            setTextColor(if (featured) Color.WHITE else navy)
        }
        val arrow = TextView(this).apply {
            text = "›"
            textSize = 25f
            gravity = Gravity.CENTER
            setTextColor(if (featured) Color.WHITE else green)
        }
        card.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        card.addView(arrow, LinearLayout.LayoutParams(-2, -2))
        val params = LinearLayout.LayoutParams(-1, dp(50))
        if (parent.childCount > 0) params.topMargin = dp(8)
        parent.addView(card, params)
    }

    private fun openPage(page: Page) {
        pageTitle.text = page.title
        web.loadUrl(base + page.path)
    }

    private fun showMoreMenu() {
        val labels = morePages.map { it.label }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Juwai Morning Teer")
            .setItems(labels) { _, which -> openPage(morePages[which]) }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (::web.isInitialized && web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
