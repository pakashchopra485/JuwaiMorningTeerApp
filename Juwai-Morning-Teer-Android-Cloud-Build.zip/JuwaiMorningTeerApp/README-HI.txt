JUWAI MORNING TEER - ANDROID APP SOURCE PROJECT

यह Android Studio का source project है। यह APK फाइल नहीं है।

ऐप में:
- Juwai Morning Teer वेबसाइट का लाइव Home page
- अलग-अलग Common Number, Preview, History और Calendar पेज
- More मेन्यू में Shillong, Khanapara, Shillong Night, Dream Number, Analytics, Updates आदि
- वेबसाइट के मौजूदा PHP/JSON/ऑटोमेशन को सर्वर पर ही चलने देता है
- ऐप के अंदर अपना Navy Blue header और navigation

बनाने का तरीका:
1. ZIP को Windows/Mac कंप्यूटर पर Extract करें।
2. Android Studio में JuwaiMorningTeerApp फोल्डर Open करें।
3. Gradle Sync पूरा होने दें।
4. Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।
5. APK app/build/outputs/apk/debug/app-debug.apk में मिलेगा।

ध्यान दें:
- इस वातावरण में Android SDK/Gradle build उपलब्ध नहीं था, इसलिए APK compile/test नहीं किया गया।
- पहली बार ऐप चलाने के लिए इंटरनेट चाहिए।
- वेबसाइट के PHP/JSON या cron automation में कोई बदलाव नहीं किया गया।
- App केवल आपकी वेबसाइट का data और pages दिखाता है; server-side automation वेबसाइट पर ही चलता है।

APK BUILD (CLOUD - GitHub Actions)
---------------------------------
Is project mein .github/workflows/build-apk.yml diya gaya hai.
GitHub par project ke files upload karne ke baad Actions tab mein
"Build Android APK" workflow ko Run workflow se chalayen.
Build safal hone par run ke Artifacts section se
"Juwai-Morning-Teer-APK" download karein. ZIP extract karke
app-debug.apk ko Android phone par install karein.

Note: Yeh debug APK hai. Is project ko Android SDK/Gradle ke saath
cloud runner par compile kiya jayega. Workflow ka result hi batayega
ki build safal hua ya source mein koi error hai.
